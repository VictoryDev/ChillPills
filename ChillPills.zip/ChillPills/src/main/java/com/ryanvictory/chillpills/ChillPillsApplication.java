package com.ryanvictory.chillpills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChillPillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChillPillsApplication.class, args);
	}

}
