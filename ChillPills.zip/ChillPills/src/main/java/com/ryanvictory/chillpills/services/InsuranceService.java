package com.ryanvictory.chillpills.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ryanvictory.chillpills.models.Insurance;
import com.ryanvictory.chillpills.repositories.InsuranceRepository;

@Service
public class InsuranceService {
	private final InsuranceRepository inRepo;

	public InsuranceService(InsuranceRepository inRepo) {
		this.inRepo = inRepo;
	}
	
	public List<Insurance> allInsurances(){
		return inRepo.findAll();
	}
}
